/********************************************************************************
* person.hpp: Inneh�ller funktionalitet f�r lagring samt utskrift av persondata
*             via strukten person.
********************************************************************************/
#ifndef PERSON_HPP_
#define PERSON_HPP_

/* Inkluderingsdirektiv: */
#include <cstdio>

/********************************************************************************
* person: Datastruktur f�r lagring av persondata.
********************************************************************************/
struct person
{
   const char* name = nullptr; /* Personens namn. */
   unsigned int age = 0;       /* Personens �lder. */

   /********************************************************************************
   * person: Konstruktor, initierar nytt person-objekt med angiven persondata.
   * 
   *         - name  : Pekare till textstycke inneh�llande personens namn.
   *         - age   : Personens �lder.
   ********************************************************************************/
   person(const char* name,
          const unsigned int age)
   {
      this->name = name;
      this->age = age;
      return;
   }

   /********************************************************************************
   * clear: Nollst�ller persondata f�r angivet objekt.
   ********************************************************************************/
   void clear(void)
   {
      this->name = nullptr;
      this->age = 0;
      return;
   }

   /********************************************************************************
   * print: Skriver ut persondata till angiven utstr�m, d�r standardutenhet
   *        stdout anv�nds som default f�r utskrift i terminalen.
   * 
   *        - ostream: Pekare till angiven utstr�m (default = stdout).
   ********************************************************************************/
   void print(FILE* ostream = stdout) const
   {
      if (!ostream) ostream = stdout;
      fprintf(ostream, "--------------------------------------------------------------------------------\n");
      fprintf(ostream, "Name: %s\n", this->name);
      fprintf(ostream, "Age: %u\n", this->age);
      fprintf(ostream, "--------------------------------------------------------------------------------\n\n");
      return;
   }
};

#endif /* PERSON_H_ */