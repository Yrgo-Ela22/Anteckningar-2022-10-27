/********************************************************************************
* main.cpp: Demonstration av struktar i C++ f�r via lagring samt utskrift av 
*           persondata. Notera att koden f�r strukten person �r skrivet i
*           C-style och enbart anv�nds f�r att demonstrera skillnad i syntax 
*           mellan struktar i C och struktar och klasser i andra spr�k. 
*           Mer avancerade koncept s�som inkapsling och behandlas d�rmed inte.
********************************************************************************/
#include "person.hpp"

/********************************************************************************
* main: Lagrar personuppgifter f�r tv� personer och skriver ut i terminalen.
********************************************************************************/
int main(void)
{
   person p1("Donald Duck", 88);
   person p2("Mickey Mouse", 93);

   p1.print();
   p2.print();

   return 0;
}