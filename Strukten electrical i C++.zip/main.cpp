/********************************************************************************
* main.cpp: Demonstration av strukt i C++ f�r lagring samt utskrift av 
*           elektriska storheter sp�nning, str�m, resistans och effekt. Detta
*           program �r skrivet enbart f�r att demonstrera grundl�ggande 
*           skillnader mellan struktar i C och struktar/klasser i andra spr�k.
*           Notera att koden �r skriven i C-style f�r att h�llas n�ra
*           motsvarande C-kod.
*
*           OBS! F�r att anv�nda funktionen fopen i Visual Studio, h�gerklicka p�
*           p� projektnamnet i Solution Explorer, klicka p� Properties => C/C++
*           => Preprocessor. I rutan Preprocessor Definitions, skriv in 
*           direktivet _CRT_SECURE_NO_WARNINGS f�reg�tt av ett blanksteg.
********************************************************************************/
#include "electrical.hpp"

/********************************************************************************
* main: Deklarerar och initierar tv� objekt d�pta e1 samt e2 och skriver sedan
*       ut de elektriska storheterna, b�de i terminalen samt till en textfil
*       d�pt electrical.txt.
********************************************************************************/
int main(void)
{
   electrical e1(24, 48);
   electrical e2(10, 2.5);
   FILE* ostream = nullptr;

   e1.print();
   e2.print();

   ostream = fopen("electrical.txt", "w");
   e1.print(ostream);
   e2.print(ostream);
   fclose(ostream);

   return 0;
}