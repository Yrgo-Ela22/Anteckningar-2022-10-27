/********************************************************************************
* electrical.hpp: Inneh�ller funktionalitet f�r lagring samt utskrift av
*                 elektriska storheter via strukten electrical samt associerade
*                 funktioner.
********************************************************************************/
#ifndef ELECTRICAL_HPP_
#define ELECTRICAL_HPP_

/* Inkluderingsdirektiv: */
#include <cstdio>

/********************************************************************************
* electrical: Strukt f�r lagring av elektriska storheter sp�nning, str�m,
*             resistans och effekt.
********************************************************************************/
struct electrical
{
   double voltage = 0;    /* Sp�nning m�tt i V. */
   double current = 0;    /* Str�m m�tt i mA. */
   double resistance = 0; /* Resistans m�tt i kOhm. */
   double power = 0;      /* Effekt m�tt i mW. */

   /********************************************************************************
   * electrical: Konstruktor, initierar objekt f�r lagring av elektriska storheter. 
   *             Angiven sp�nning och str�m lagras och anv�nds f�r att ber�kna 
   *             motsvarande resistans och effekt.
   *
   *             - voltage: Sp�nning m�tt i V.
   *             - current: Str�m m�tt i mA.
   ********************************************************************************/
   electrical(const double voltage,
              const double current)
   {
      this->voltage = voltage;
      this->current = current;
      this->resistance = voltage / current;
      this->power = voltage * current;
      return;
   }

   /********************************************************************************
   * clear: Nollst�ller angivet electrical-objekt innan det g�r ur scope.
   ********************************************************************************/
   void clear(void)
   {
      this->voltage = 0;
      this->current = 0;
      this->resistance = 0;
      this->power = 0;
      return;
   }

   /********************************************************************************
   * print: Skriver ut lagrade elektriska storheter via angiven utstr�m, d�r 
   *        standardutenheten stdout anv�nds som default f�r utskrift i terminalen.
   * 
   *        - ostream: Pekare till angiven utstr�m (default = stdout).
   ********************************************************************************/
   void print(FILE* ostream = stdout) const
   {
      if (!ostream) ostream = stdout;
      fprintf(ostream, "--------------------------------------------------------------------------------\n");
      fprintf(ostream, "Voltage: %lg V\n", this->voltage);
      fprintf(ostream, "Current: %lg mA\n", this->current);
      fprintf(ostream, "Resistance: %lg kOhm\n", this->resistance);
      fprintf(ostream, "Power: %lg mW\n", this->power);
      fprintf(ostream, "--------------------------------------------------------------------------------\n\n");
      return;
   }
};

#endif /* ELECTRICAL_HPP_ */