/********************************************************************************
* main.c: Demonstration av struktar i C via lagring och utskrift av persondata.
* 
*         Notering: I C �r det m�jligt att initiera struktar som en array.
*         Som exempel, objektet p1 i main hade kunnat initieras enligt nedan
*         i st�llet f�r via anrop av funktionen person_init:
* 
*         struct person p1 = 
          {
             .name = "Donald Duck",
             .age = 88
          };
********************************************************************************/
#include "person.h"

/********************************************************************************
* main: Lagrar personuppgifter f�r tv� personer och skriver ut i terminalen.
********************************************************************************/
int main(void)
{
   struct person p1, p2;

   person_init(&p1, "Donald Duck", 88);
   person_init(&p2, "Mickey Mouse", 93);
   
   person_print(&p1, 0);
   person_print(&p2, 0);

   return 0;
}