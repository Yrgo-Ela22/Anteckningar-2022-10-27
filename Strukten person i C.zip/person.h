/********************************************************************************
* person.h: Inneh�ller funktionalitet f�r lagring samt utskrift av persondata
*           via strukten person samt associerade funktioner.
********************************************************************************/
#ifndef PERSON_H_
#define PERSON_H_

/* Inkluderingsdirektiv: */
#include <stdio.h>

/********************************************************************************
* person: Datastruktur f�r lagring av persondata.
********************************************************************************/
struct person
{
   const char* name;       /* Personens namn. */
   unsigned int age;       /* Personens �lder. */
};

/********************************************************************************
* person_init: Initierar nytt person-objekt med angiven persondata.
* 
*              - self  : Pekare till objektet som skall initieras.
*              - name  : Pekare till textstycke inneh�llande personens namn.
*              - age   : Personens �lder.
********************************************************************************/
void person_init(struct person* self,
                 const char* name,
                 const unsigned int age);

/********************************************************************************
* person_clear: Nollst�ller person-objekt.
*
*               - self: Pekare till objektet som skall nollst�llas.
********************************************************************************/
void person_clear(struct person* self);

/********************************************************************************
* person_print: Skriver ut persondata till angiven utstr�m, d�r standardutenhet
*               stdout anv�nds som default f�r utskrift i terminalen.
* 
*               - self   : Pekare till objekt inneh�llande persondatan som
*                          skall skrivas ut.
*               - ostream: Pekare till angiven utstr�m (default = stdout).
********************************************************************************/
void person_print(const struct person* self,
                  FILE* ostream);

#endif /* PERSON_H_ */