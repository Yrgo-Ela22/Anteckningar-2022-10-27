/********************************************************************************
* person.c: Funktionsdefinitioner f�r lagring samt utskrift av persondata
*           via strukten person.
********************************************************************************/
#include "person.h"

/********************************************************************************
* person_init: Initierar nytt person-objekt med angiven persondata.
*
*              - self  : Pekare till objektet som skall initieras.
*              - name  : Pekare till textstycke inneh�llande personens namn.
*              - age   : Personens �lder.
********************************************************************************/
void person_init(struct person* self,
                 const char* name,
                 const unsigned int age)
{
   self->name = name;
   self->age = age;
   return;
}

/********************************************************************************
* person_clear: Nollst�ller person-objekt.
*
*               - self: Pekare till objektet som skall nollst�llas.
********************************************************************************/
void person_clear(struct person* self)
{
   self->name = 0;
   self->age = 0;
   return;
}

/********************************************************************************
* person_print: Skriver ut persondata till angiven utstr�m, d�r standardutenhet
*               stdout anv�nds som default f�r utskrift i terminalen.
*
*               - self   : Pekare till objekt inneh�llande persondatan som
*                          skall skrivas ut.
*               - ostream: Pekare till angiven utstr�m (default = stdout).
********************************************************************************/
void person_print(const struct person* self,
                  FILE* ostream)
{
   if (!ostream) ostream = stdout;
   fprintf(ostream, "--------------------------------------------------------------------------------\n");

   fprintf(ostream, "Name: %s\n", self->name);
   fprintf(ostream, "Age: %u\n", self->age);
   fprintf(ostream, "--------------------------------------------------------------------------------\n\n");
   return;
}